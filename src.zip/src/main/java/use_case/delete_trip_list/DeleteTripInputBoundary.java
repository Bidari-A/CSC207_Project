package use_case.delete_trip_list;

public interface DeleteTripInputBoundary {
    void delete(DeleteTripInputData data);
}
