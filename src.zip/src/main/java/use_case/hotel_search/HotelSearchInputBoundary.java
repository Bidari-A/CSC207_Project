package use_case.hotel_search;

public interface HotelSearchInputBoundary {
    void execute(HotelSearchInputData inputData);
}
