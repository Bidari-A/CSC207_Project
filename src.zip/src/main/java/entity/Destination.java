package entity;

public class Destination {
    private final String name;

    public Destination(String name) {
        this.name = name;
    }

    public String getName() {return name;}
}
