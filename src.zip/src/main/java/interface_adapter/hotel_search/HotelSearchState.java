package interface_adapter.hotel_search;

public class HotelSearchState {
    private String summary = "";

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
}